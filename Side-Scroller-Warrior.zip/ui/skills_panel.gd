extends VBoxContainer
const Catalog=preload("res://data/catalog.gd")
const Style=preload("res://ui/style.gd")
var state
var bindings
var selected_tier=1
var note=""
func bind(s,b=null):
    state=s
    bindings=b
    selected_tier=maxi(1,state.tier())
    refresh()
func assign_skill(slot: String,id: String) -> bool:
    var result=state.assign_skill(slot,id)
    note="Assigned to "+slot_label(slot)+". Existing skills move or swap automatically." if result else "Learn this skill and unlock its job tier first."
    refresh()
    return result
func refresh():
    Style.clear(self)
    add_child(Style.label("SKILLS & JOB TREE",24,Color("f4d48a")))
    var tabs=HBoxContainer.new()
    add_child(tabs)
    for i in range(1,6):
        var text=(["Thief 10","Assassin 30","Hermit 60","Night Lord 100","Hyper 140+"] if state.archetype=="thief" else ["Warrior 10","Spearman 30","Dragon Knight 60","Dark Knight 100","Hyper 140+"])[i-1]
        tabs.add_child(Style.button(text,func(): selected_tier=i; refresh()))
    if selected_tier>4 or state.archetype=="warrior" and selected_tier>2:
        add_child(Style.label("FUTURE JOB — NOT PLAYABLE IN THIS BUILD",20,Color("bba8dc")))
        var explanation="Dragon Knight: erupting spears and larger area attacks." if selected_tier==3 else "Dark Knight: powerful mob clearing, boss damage and a map attack." if selected_tier==4 else "Hyper: passive skill modifiers, powerful buffs and burst attacks."
        if state.archetype=="thief": explanation="Hyper skills are future content. Thief job-based stars and Shadow Partner are playable."
        add_child(Style.label(explanation,17))
        return
    add_child(Style.label("Tier %d skill points: %d  |  %s" % [selected_tier,state.sp[str(selected_tier)],"Advance with the town instructor to unlock this tier." if selected_tier>state.tier() else "Spend points to increase ranks; assign learned attacks below."],16))
    var hotbar=HBoxContainer.new()
    add_child(hotbar)
    for slot in ["z","x","c"]:
        var assigned=state.slots[slot]
        hotbar.add_child(Style.label(slot_label(slot)+": "+(Catalog.skills()[assigned].name if assigned!="" else "Empty"),15,Color("f4d48a")))
    if note!="": add_child(Style.label(note,15,Color("8ed9d0")))
    if state.archetype=="thief":
        add_child(Style.label("Basic stars: Thief 1 → Assassin 2 → Hermit 3 → Night Lord 4",16,Color("8ed9d0")))
        if selected_tier>=2:
            add_child(Style.label("Advance with Elowen at level %d. %d stars per basic attack.\n%s" % [{2:30,3:60,4:100}[selected_tier],selected_tier,"Hermit unlocks Shadow Partner, mirroring your stars for 60 seconds." if selected_tier>=3 else ""],15,Color("bfaee5")))
    elif selected_tier==2:
        add_child(Style.label("Spear Mastery  ->  Ground Wave\nBattle Vigor (independent passive)",16,Color("8ed9d0")))
    else:
        add_child(Style.label("Shadow Fan  •  Claw Precision  •  Shadow Guard" if state.archetype=="thief" else "Crescent Sweep  •  Driving Thrust  •  Strength Training  •  Iron Skin",15,Color("8ed9d0")))
    for id in Catalog.skills():
        var skill=Catalog.skills()[id]
        if skill.tier!=selected_tier or not state.skill_belongs(id): continue
        var row=VBoxContainer.new()
        row.add_theme_constant_override("separation",3)
        add_child(row)
        var rank=state.skill_ranks.get(id,0)
        var line=HBoxContainer.new()
        row.add_child(line)
        var text=Style.label("%s   %d / %d" % [skill.name,rank,skill.max],18)
        text.custom_minimum_size.x=300
        line.add_child(text)
        var rank_button=Style.button("Rank +1",func():
            note="Rank increased." if state.rank_up(id) else "Need a skill point, unlocked tier, and any prerequisite."
            refresh())
        rank_button.disabled=rank>=skill.max or selected_tier>state.tier() or state.sp[str(selected_tier)]<=0 or (skill.has("requires") and state.skill_ranks.get(skill.requires,0)<1)
        line.add_child(rank_button)
        if skill.active:
            for slot in ["z","x","c"]:
                var button=Style.button(slot_label(slot)+(" (on)" if state.slots[slot]==id else ""),func(): assign_skill(slot,id))
                button.custom_minimum_size.x=56
                button.disabled=not state.can_use(id)
                button.tooltip_text="Move or swap this skill into "+slot_label(slot)+"." if state.can_use(id) else "Locked: unlock this job and learn rank 1 first."
                line.add_child(button)
        row.add_child(Style.label(skill.description,14,Color("acc6c6")))
        if skill.active and not skill.get("buff",false):
            row.add_child(Style.label("%d MP  •  %.1fs cooldown  •  %d targets  •  Next rank: +15%% base attack" % [skill.mana,skill.cooldown,skill.targets+(int(maxi(0,rank-1)/2.0) if id=="wave" else 0)],13,Color("e1bf83")))


func slot_label(slot: String) -> String:
    if bindings!=null: return OS.get_keycode_string(bindings.current()["skill_"+slot])
    return slot.to_upper()
